package com.myblog13.myblog13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Myblog13Application {

	public static void main(String[] args) {
		SpringApplication.run(Myblog13Application.class, args);
	}

}
