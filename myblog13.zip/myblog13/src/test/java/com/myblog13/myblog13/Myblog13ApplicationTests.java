package com.myblog13.myblog13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Myblog13ApplicationTests {

	@Test
	void contextLoads() {
	}

}
